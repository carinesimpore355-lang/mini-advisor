"""
analyzer.py — Calculs financiers sur le portefeuille.

Métriques calculées :
- Valeur totale actuelle
- P&L (Profit & Loss) global et par actif
- Allocation (% par actif)
- Volatilité (écart-type des rendements journaliers sur 30j)
- Score de santé (0-100)
"""
import numpy as np
from modules.data_fetcher import DataFetcher
from config import THRESHOLDS, CURRENCY


class Analyzer:
    """Calcule toutes les métriques du portefeuille."""

    def __init__(self, holdings: list):
        self.holdings = holdings
        self.fetcher = DataFetcher()
        self._prices = {}
        if holdings:
            coin_ids = [h["coin_id"] for h in holdings]
            self._prices = self.fetcher.get_current_prices(coin_ids)

    def get_enriched_holdings(self) -> list:
        """
        Enrichit chaque holding avec les données de marché actuelles.
        C'est la base pour tout le reste.
        """
        enriched = []
        for h in self.holdings:
            price_data = self._prices.get(h["coin_id"], {})
            current_price = price_data.get(CURRENCY, 0)
            change_24h = price_data.get(f"{CURRENCY}_24h_change", 0)

            invested = h["quantity"] * h["buy_price"]
            current_value = h["quantity"] * current_price
            pnl = current_value - invested
            pnl_pct = (pnl / invested * 100) if invested > 0 else 0

            enriched.append({
                **h,
                "current_price": current_price,
                "change_24h": change_24h,
                "invested": invested,
                "current_value": current_value,
                "pnl": pnl,
                "pnl_pct": pnl_pct,
            })
        return enriched

    def get_total_value(self) -> float:
        """Valeur totale actuelle du portefeuille."""
        return sum(h["current_value"] for h in self.get_enriched_holdings())

    def get_total_invested(self) -> float:
        """Capital total investi (coût de base)."""
        return sum(h["quantity"] * h["buy_price"] for h in self.holdings)

    def get_total_pnl(self) -> tuple[float, float]:
        """Retourne (P&L absolu, P&L %)."""
        invested = self.get_total_invested()
        current = self.get_total_value()
        pnl = current - invested
        pnl_pct = (pnl / invested * 100) if invested > 0 else 0
        return pnl, pnl_pct

    def get_allocation(self) -> list:
        """
        Allocation en % de chaque actif.
        Retourne : [{"symbol": "BTC", "pct": 45.0, "value": 450.0}, ...]
        """
        enriched = self.get_enriched_holdings()
        total = self.get_total_value()
        if total == 0:
            return []
        return [
            {
                "symbol": h["symbol"],
                "coin_id": h["coin_id"],
                "pct": (h["current_value"] / total) * 100,
                "value": h["current_value"],
            }
            for h in enriched
        ]

    def get_volatility(self, coin_id: str, days: int = 30) -> float:
        """
        Volatilité = écart-type des rendements journaliers (en %).
        Une volatilité de 5% signifie que le prix bouge en moyenne de ±5%/jour.
        """
        history = self.fetcher.get_historical_prices(coin_id, days)
        if len(history) < 2:
            return 0.0

        prices = np.array([p[1] for p in history])
        # Rendements journaliers = (prix_jour_n / prix_jour_n-1) - 1
        returns = np.diff(prices) / prices[:-1]
        # Écart-type × 100 pour avoir un %
        return float(np.std(returns) * 100)

    def get_performance_30d(self, coin_id: str) -> float:
        """Performance sur 30 jours en %."""
        history = self.fetcher.get_historical_prices(coin_id, 30)
        if len(history) < 2:
            return 0.0
        start, end = history[0][1], history[-1][1]
        return ((end - start) / start) * 100 if start > 0 else 0.0

    def get_health_score(self) -> dict:
        """
        Score de santé du portefeuille (0-100).
        Pondération :
            - Diversification (40 pts) : nb d'actifs + pas de concentration
            - Performance (30 pts)     : P&L positif
            - Volatilité (30 pts)      : volatilité moyenne raisonnable
        """
        if not self.holdings:
            return {"score": 0, "grade": "N/A", "details": []}

        details = []

        # --- 1. DIVERSIFICATION (40 pts) ---
        n_assets = len(self.holdings)
        allocation = self.get_allocation()
        max_alloc = max((a["pct"] for a in allocation), default=0)

        diversif_score = 0
        if n_assets >= THRESHOLDS["min_assets_diversified"]:
            diversif_score += 20
            details.append(f"✅ Bien diversifié ({n_assets} actifs)")
        else:
            details.append(f"⚠️ Peu diversifié ({n_assets} actifs, min recommandé : {THRESHOLDS['min_assets_diversified']})")

        if max_alloc <= THRESHOLDS["max_allocation_pct"]:
            diversif_score += 20
            details.append(f"✅ Pas de sur-concentration (max {max_alloc:.1f}%)")
        else:
            # Dégradé : plus on dépasse, plus on perd
            penalty = min(20, (max_alloc - THRESHOLDS["max_allocation_pct"]) / 3)
            diversif_score += max(0, 20 - penalty)
            details.append(f"⚠️ Concentration élevée (1 actif = {max_alloc:.1f}%)")

        # --- 2. PERFORMANCE (30 pts) ---
        _, pnl_pct = self.get_total_pnl()
        if pnl_pct > 10:
            perf_score = 30
            details.append(f"✅ Très bonne performance ({pnl_pct:+.1f}%)")
        elif pnl_pct > 0:
            perf_score = 20
            details.append(f"✅ Performance positive ({pnl_pct:+.1f}%)")
        elif pnl_pct > -10:
            perf_score = 10
            details.append(f"➖ Performance négative modérée ({pnl_pct:+.1f}%)")
        else:
            perf_score = 0
            details.append(f"🔴 Performance très négative ({pnl_pct:+.1f}%)")

        # --- 3. VOLATILITÉ (30 pts) ---
        volatilities = [self.get_volatility(h["coin_id"]) for h in self.holdings]
        avg_vol = np.mean(volatilities) if volatilities else 0

        if avg_vol < 4:
            vol_score = 30
            details.append(f"✅ Volatilité faible ({avg_vol:.1f}%)")
        elif avg_vol < THRESHOLDS["high_volatility_pct"]:
            vol_score = 20
            details.append(f"➖ Volatilité modérée ({avg_vol:.1f}%)")
        else:
            vol_score = 5
            details.append(f"⚠️ Volatilité élevée ({avg_vol:.1f}%)")

        total = diversif_score + perf_score + vol_score

        # Note sous forme de lettre
        if total >= 80:
            grade = "A 🏆"
        elif total >= 65:
            grade = "B 👍"
        elif total >= 50:
            grade = "C ➖"
        elif total >= 35:
            grade = "D ⚠️"
        else:
            grade = "F 🔴"

        return {
            "score": round(total),
            "grade": grade,
            "details": details,
            "subscores": {
                "diversification": round(diversif_score),
                "performance": round(perf_score),
                "volatility": round(vol_score),
            }
        }

    def simulate_investment(self, coin_id: str, amount: float) -> dict:
        """
        Simulation "Si j'avais investi X$ il y a 30 jours dans cet actif".
        """
        history = self.fetcher.get_historical_prices(coin_id, 30)
        if len(history) < 2:
            return {"error": "Historique indisponible"}

        price_start = history[0][1]
        price_end = history[-1][1]
        quantity = amount / price_start
        final_value = quantity * price_end
        pnl = final_value - amount
        pnl_pct = (pnl / amount) * 100

        return {
            "invested": amount,
            "final_value": final_value,
            "pnl": pnl,
            "pnl_pct": pnl_pct,
            "quantity": quantity,
        }
