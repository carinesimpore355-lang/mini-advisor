"""
notifier.py — Envoie des notifications par email et/ou Telegram.

Email : utilise Gmail SMTP (gratuit, mot de passe d'application requis).
Telegram : gratuit, il faut créer un bot via @BotFather.
"""
import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import EMAIL_CONFIG, TELEGRAM_CONFIG


class Notifier:
    """Gère l'envoi de notifications multi-canaux."""

    # ===== EMAIL =====

    @staticmethod
    def send_email(subject: str, body: str) -> tuple[bool, str]:
        """
        Envoie un email via Gmail SMTP.

        PRÉREQUIS :
        1. Activer la 2FA sur ton compte Google
        2. Créer un "mot de passe d'application" :
           https://myaccount.google.com/apppasswords
        3. Mettre les credentials dans .env :
           EMAIL_SENDER=ton@gmail.com
           EMAIL_PASSWORD=xxxx xxxx xxxx xxxx
           EMAIL_RECEIVER=destinataire@gmail.com
        """
        cfg = EMAIL_CONFIG
        if not cfg["sender"] or not cfg["password"]:
            return False, "Credentials email non configurés (.env)"

        msg = MIMEMultipart()
        msg["From"] = cfg["sender"]
        msg["To"] = cfg["receiver"] or cfg["sender"]
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain", "utf-8"))

        try:
            with smtplib.SMTP(cfg["smtp_server"], cfg["smtp_port"]) as server:
                server.starttls()
                server.login(cfg["sender"], cfg["password"])
                server.send_message(msg)
            return True, "Email envoyé ✅"
        except Exception as e:
            return False, f"Erreur email : {e}"

    # ===== TELEGRAM =====

    @staticmethod
    def send_telegram(message: str) -> tuple[bool, str]:
        """
        Envoie un message Telegram.

        PRÉREQUIS :
        1. Ouvrir Telegram, chercher @BotFather
        2. /newbot → suivre les instructions → récupérer le TOKEN
        3. Envoyer un message à ton bot
        4. Récupérer ton CHAT_ID : https://api.telegram.org/bot<TOKEN>/getUpdates
        5. Mettre dans .env :
           TELEGRAM_BOT_TOKEN=123456:ABC...
           TELEGRAM_CHAT_ID=123456789
        """
        cfg = TELEGRAM_CONFIG
        if not cfg["bot_token"] or not cfg["chat_id"]:
            return False, "Credentials Telegram non configurés (.env)"

        url = f"https://api.telegram.org/bot{cfg['bot_token']}/sendMessage"
        payload = {
            "chat_id": cfg["chat_id"],
            "text": message,
            "parse_mode": "Markdown",
        }
        try:
            r = requests.post(url, json=payload, timeout=10)
            r.raise_for_status()
            return True, "Telegram envoyé ✅"
        except requests.RequestException as e:
            return False, f"Erreur Telegram : {e}"

    # ===== HELPERS =====

    @staticmethod
    def format_recommendations(recos: list, health_score: dict) -> str:
        """Formate les recommandations en texte lisible pour notification."""
        lines = [
            f"🚀 MINI ADVISOR — Rapport portefeuille",
            f"",
            f"Score santé : {health_score['score']}/100 ({health_score['grade']})",
            f"",
            f"Recommandations :",
        ]
        for r in recos[:5]:  # Top 5 max
            lines.append(f"• [{r['severity']}] {r['reason']}")
        return "\n".join(lines)

    @classmethod
    def send_all(cls, subject: str, body: str) -> dict:
        """Envoie sur tous les canaux configurés."""
        results = {}
        ok_email, msg_email = cls.send_email(subject, body)
        results["email"] = {"ok": ok_email, "msg": msg_email}
        ok_tg, msg_tg = cls.send_telegram(body)
        results["telegram"] = {"ok": ok_tg, "msg": msg_tg}
        return results
