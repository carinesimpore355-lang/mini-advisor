"""
ai_agent.py — Agent IA de recommandations.

V1 : système expert (règles "si... alors...")
V2 : peut être branché sur OpenAI / Claude API plus tard (voir méthode ask_llm).

Chaque recommandation a :
- action : BUY / SELL / HOLD / REBALANCE / ALERT
- asset : sur quoi porte la reco
- reason : explication lisible
- severity : LOW / MEDIUM / HIGH
"""
from config import THRESHOLDS


class AIAgent:
    """Agent de recommandations basé sur des règles métier."""

    def __init__(self, analyzer):
        self.analyzer = analyzer

    def analyze(self) -> list:
        """
        Analyse complète du portefeuille.
        Retourne une liste de recommandations triées par sévérité.
        """
        if not self.analyzer.holdings:
            return [{
                "action": "INFO",
                "asset": "—",
                "reason": "Portefeuille vide. Commencez par ajouter des actifs.",
                "severity": "LOW",
            }]

        recommendations = []
        recommendations += self._check_concentration()
        recommendations += self._check_performance()
        recommendations += self._check_volatility()
        recommendations += self._check_market_moves()
        recommendations += self._check_diversification()

        # Tri par sévérité : HIGH > MEDIUM > LOW
        severity_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        recommendations.sort(key=lambda r: severity_order.get(r["severity"], 3))

        return recommendations if recommendations else [{
            "action": "HOLD",
            "asset": "Global",
            "reason": "✅ Portefeuille sain. Aucune action urgente recommandée.",
            "severity": "LOW",
        }]

    # ===== RÈGLES =====

    def _check_concentration(self) -> list:
        """Règle 1 : Un actif représente trop du portefeuille."""
        recos = []
        allocation = self.analyzer.get_allocation()
        for a in allocation:
            if a["pct"] > THRESHOLDS["max_allocation_pct"]:
                recos.append({
                    "action": "REBALANCE",
                    "asset": a["symbol"],
                    "reason": (
                        f"⚠️ {a['symbol']} représente {a['pct']:.1f}% de votre portefeuille "
                        f"(seuil : {THRESHOLDS['max_allocation_pct']}%). "
                        f"Envisagez de vendre une partie pour réduire le risque."
                    ),
                    "severity": "HIGH" if a["pct"] > 60 else "MEDIUM",
                })
        return recos

    def _check_performance(self) -> list:
        """Règle 2 : Stop-loss et take-profit sur 30 jours."""
        recos = []
        for h in self.analyzer.get_enriched_holdings():
            perf_30d = self.analyzer.get_performance_30d(h["coin_id"])

            # Stop-loss : l'actif chute fortement
            if perf_30d < THRESHOLDS["stop_loss_pct"]:
                recos.append({
                    "action": "SELL",
                    "asset": h["symbol"],
                    "reason": (
                        f"🔴 {h['symbol']} a chuté de {perf_30d:.1f}% sur 30 jours. "
                        f"Envisagez de couper les pertes (stop-loss)."
                    ),
                    "severity": "HIGH",
                })
            # Take-profit : l'actif a beaucoup monté
            elif perf_30d > THRESHOLDS["take_profit_pct"]:
                recos.append({
                    "action": "SELL",
                    "asset": h["symbol"],
                    "reason": (
                        f"💰 {h['symbol']} a progressé de +{perf_30d:.1f}% sur 30 jours. "
                        f"Envisagez de prendre des bénéfices partiels."
                    ),
                    "severity": "MEDIUM",
                })

            # P&L personnel très négatif
            if h["pnl_pct"] < -30:
                recos.append({
                    "action": "ALERT",
                    "asset": h["symbol"],
                    "reason": f"🔴 Votre position {h['symbol']} est en perte de {h['pnl_pct']:.1f}%.",
                    "severity": "HIGH",
                })
        return recos

    def _check_volatility(self) -> list:
        """Règle 3 : Volatilité excessive."""
        recos = []
        for h in self.analyzer.holdings:
            vol = self.analyzer.get_volatility(h["coin_id"])
            if vol > THRESHOLDS["high_volatility_pct"]:
                recos.append({
                    "action": "ALERT",
                    "asset": h["symbol"],
                    "reason": (
                        f"⚡ {h['symbol']} a une volatilité de {vol:.1f}%/jour (élevée). "
                        f"Taille de position à surveiller."
                    ),
                    "severity": "MEDIUM",
                })
        return recos

    def _check_market_moves(self) -> list:
        """Règle 4 : Mouvements de marché sur 24h."""
        recos = []
        for h in self.analyzer.get_enriched_holdings():
            change = h["change_24h"]
            if abs(change) >= THRESHOLDS["market_alert_pct"]:
                direction = "📈 hausse" if change > 0 else "📉 baisse"
                recos.append({
                    "action": "ALERT",
                    "asset": h["symbol"],
                    "reason": f"{direction} forte de {change:+.1f}% sur 24h pour {h['symbol']}.",
                    "severity": "MEDIUM" if abs(change) < 20 else "HIGH",
                })
        return recos

    def _check_diversification(self) -> list:
        """Règle 5 : Diversification insuffisante."""
        n = len(self.analyzer.holdings)
        if n < THRESHOLDS["min_assets_diversified"]:
            return [{
                "action": "REBALANCE",
                "asset": "Portefeuille",
                "reason": (
                    f"📊 Vous n'avez que {n} actif(s). "
                    f"Pour mieux diversifier, visez au moins "
                    f"{THRESHOLDS['min_assets_diversified']} actifs de secteurs différents "
                    f"(Layer 1, DeFi, Stablecoins...)."
                ),
                "severity": "MEDIUM",
            }]
        return []

    # ===== HOOK POUR IA EXTERNE (OPENAI / CLAUDE) =====

    def ask_llm(self, api_key: str = None) -> str:
        """
        Hook pour brancher un LLM plus tard (OpenAI, Claude, etc.).
        Pour l'instant retourne une synthèse locale.

        Pour activer : décommenter le code OpenAI, ajouter openai dans requirements.txt,
        et passer OPENAI_API_KEY en variable d'environnement.
        """
        # ----- VERSION LOCALE (pas besoin d'API) -----
        recos = self.analyze()
        health = self.analyzer.get_health_score()
        _, pnl_pct = self.analyzer.get_total_pnl()

        summary = [
            f"📊 **Score santé : {health['score']}/100 ({health['grade']})**",
            f"💰 P&L global : {pnl_pct:+.2f}%",
            "",
            f"🎯 **Top actions recommandées ({len(recos)}) :**",
        ]
        for r in recos[:3]:
            summary.append(f"- [{r['severity']}] {r['action']} {r['asset']} — {r['reason']}")
        return "\n".join(summary)

        # ----- VERSION OPENAI (à activer plus tard) -----
        # import openai
        # openai.api_key = api_key
        # prompt = f"Analyse ce portefeuille : {self.analyzer.get_enriched_holdings()}"
        # response = openai.ChatCompletion.create(
        #     model="gpt-4o-mini",
        #     messages=[{"role": "user", "content": prompt}]
        # )
        # return response.choices[0].message.content
