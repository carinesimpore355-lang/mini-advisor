"""
portfolio.py — Gère le portefeuille utilisateur.

Stockage simple : un fichier JSON local. Pas besoin de DB pour 1 utilisateur.
Structure d'un holding :
    {
        "coin_id": "bitcoin",
        "symbol": "BTC",
        "quantity": 0.01,
        "buy_price": 60000.0,   # Prix moyen d'achat
        "added_on": "2025-01-15"
    }
"""
import json
from datetime import datetime
from pathlib import Path
from config import PORTFOLIO_FILE, DATA_DIR


class Portfolio:
    """Gère le CRUD du portefeuille (Create / Read / Update / Delete)."""

    def __init__(self):
        DATA_DIR.mkdir(exist_ok=True)
        if not PORTFOLIO_FILE.exists():
            self._save([])

    def _load(self) -> list:
        """Charge le portefeuille depuis le fichier JSON."""
        try:
            with open(PORTFOLIO_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def _save(self, holdings: list) -> None:
        """Sauve le portefeuille dans le fichier JSON."""
        with open(PORTFOLIO_FILE, "w", encoding="utf-8") as f:
            json.dump(holdings, f, indent=2, ensure_ascii=False)

    def get_all(self) -> list:
        """Retourne tous les holdings."""
        return self._load()

    def add(self, coin_id: str, symbol: str, quantity: float, buy_price: float) -> None:
        """
        Ajoute (ou met à jour en moyennant) un holding.
        Si l'actif existe déjà, on calcule le prix moyen pondéré d'achat (DCA).
        """
        holdings = self._load()

        # Cherche si on a déjà cet actif
        for h in holdings:
            if h["coin_id"] == coin_id:
                # Calcul du prix moyen pondéré (Dollar Cost Averaging)
                total_old = h["quantity"] * h["buy_price"]
                total_new = quantity * buy_price
                total_qty = h["quantity"] + quantity
                h["buy_price"] = (total_old + total_new) / total_qty
                h["quantity"] = total_qty
                self._save(holdings)
                return

        # Nouvel actif
        holdings.append({
            "coin_id": coin_id,
            "symbol": symbol.upper(),
            "quantity": quantity,
            "buy_price": buy_price,
            "added_on": datetime.now().strftime("%Y-%m-%d"),
        })
        self._save(holdings)

    def remove(self, coin_id: str) -> None:
        """Supprime un actif du portefeuille."""
        holdings = [h for h in self._load() if h["coin_id"] != coin_id]
        self._save(holdings)

    def update_quantity(self, coin_id: str, new_quantity: float) -> None:
        """Modifie la quantité (ex: après une vente partielle)."""
        holdings = self._load()
        for h in holdings:
            if h["coin_id"] == coin_id:
                h["quantity"] = new_quantity
                break
        self._save(holdings)

    def clear(self) -> None:
        """Vide le portefeuille (utile pour reset)."""
        self._save([])

    def get_coin_ids(self) -> list:
        """Liste des coin_ids (utile pour appeler l'API)."""
        return [h["coin_id"] for h in self._load()]
