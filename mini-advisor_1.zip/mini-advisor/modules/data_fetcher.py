"""
data_fetcher.py — Récupère les données de marché depuis CoinGecko.

CoinGecko est gratuit, sans clé API, et couvre +10 000 cryptos.
On cache les résultats pour éviter de spammer l'API (rate limit).
"""
import requests
import streamlit as st
from datetime import datetime
from config import COINGECKO_API, CURRENCY


class DataFetcher:
    """Interface avec CoinGecko. Toutes les méthodes sont cachées (cache Streamlit)."""

    @staticmethod
    @st.cache_data(ttl=60)  # Cache 60 secondes : évite de spammer l'API
    def get_current_prices(coin_ids: list[str]) -> dict:
        """
        Récupère les prix actuels + variation 24h.

        Args:
            coin_ids: liste d'IDs CoinGecko (ex: ["bitcoin", "ethereum"])

        Returns:
            {"bitcoin": {"usd": 65000, "usd_24h_change": 2.5}, ...}
        """
        if not coin_ids:
            return {}

        url = f"{COINGECKO_API}/simple/price"
        params = {
            "ids": ",".join(coin_ids),
            "vs_currencies": CURRENCY,
            "include_24hr_change": "true",
            "include_market_cap": "true",
        }

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            st.error(f"⚠️ Erreur API CoinGecko : {e}")
            return {}

    @staticmethod
    @st.cache_data(ttl=3600)  # Cache 1h : les historiques bougent peu
    def get_historical_prices(coin_id: str, days: int = 30) -> list:
        """
        Historique des prix sur N jours.

        Returns:
            Liste de [timestamp_ms, prix] ex: [[1704067200000, 42000.0], ...]
        """
        url = f"{COINGECKO_API}/coins/{coin_id}/market_chart"
        params = {"vs_currency": CURRENCY, "days": days}

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json().get("prices", [])
        except requests.RequestException as e:
            st.warning(f"⚠️ Historique indisponible pour {coin_id} : {e}")
            return []

    @staticmethod
    @st.cache_data(ttl=86400)  # Cache 24h : la liste bouge peu
    def search_coin(query: str) -> list:
        """
        Cherche une crypto par nom ou symbole.
        Utile pour aider l'utilisateur à trouver le bon 'id' CoinGecko.
        """
        url = f"{COINGECKO_API}/search"
        try:
            response = requests.get(url, params={"query": query}, timeout=10)
            response.raise_for_status()
            return response.json().get("coins", [])[:10]
        except requests.RequestException:
            return []

    @staticmethod
    @st.cache_data(ttl=3600)
    def get_top_coins(limit: int = 50) -> list:
        """Top N cryptos par capitalisation (pour le dropdown)."""
        url = f"{COINGECKO_API}/coins/markets"
        params = {
            "vs_currency": CURRENCY,
            "order": "market_cap_desc",
            "per_page": limit,
            "page": 1,
        }
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.RequestException:
            return []
